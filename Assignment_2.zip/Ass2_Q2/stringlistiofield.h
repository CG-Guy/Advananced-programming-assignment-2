#ifndef STRINGLISTIOFIELD_H
#define STRINGLISTIOFIELD_H
#include "iofield.h"
#include <QComboBox>
#include <QMainWindow>

class StringListIOField:public IOField
{
public:
    StringListIOField();
    ~StringListIOField();

    QVariant getValue();
    void setValue(QVariant value);
    QWidget* getWidget();

private:
    QComboBox* stringListField;


};

#endif // STRINGLISTIOFIELD_H
