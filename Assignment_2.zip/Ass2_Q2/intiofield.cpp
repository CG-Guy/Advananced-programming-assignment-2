#include "intiofield.h"


IntIOField::IntIOField()
{
    intField = new QSpinBox();
}

IntIOField::~IntIOField()
{
    delete intField;
}

QVariant IntIOField::getValue()
{
    return intField->value();
}

void IntIOField::setValue(QVariant value)
{
    intField->setValue(value.toInt());
}

QWidget *IntIOField::getWidget()
{
    return intField;
}
