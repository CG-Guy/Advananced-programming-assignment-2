#ifndef IOFACTORY_H
#define IOFACTORY_H
#include "abstractfactory.h"
#include "intiofield.h"
#include "stringiofield.h"
#include "stringlistiofield.h"


//singleton
class ioFactory: public AbstractFactory
{
public:


    static ioFactory* getInstance();//Independent instance (Call function without instance)

    IOField *createIOField(QString VariableType);

private:
    ioFactory();//Singleton the constructor is private

    static ioFactory* OneInstance; //Store one instance
};

#endif // IOFACTORY_H
