#include "abstractfactory.h"

AbstractFactory::AbstractFactory()
{
}
