#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "operations.h"
#include "intoperations.h"
#include "stringoperations.h"
#include <QDataStream>
#include <QDebug>


//The does the auto file load
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    ui->radioInteger->setChecked(true);

    ui->lineEdit->hide();
    ui->lineEdit_2->hide();
    ui->spinBox->hide();
    ui->spinBox_2->hide();
    ui->comboBox->hide();
    ui->comboBox_2->hide();

    ui->label->hide();
    ui->label_2->hide();
    ui->label_3->hide();
    ui->label_4->hide();
    ui->label_5->hide();
    ui->label_6->hide();
    ui->comboBox_3->hide();
    ui->lineEdit_3->hide();
    ui->spinBox_3->hide();


    factory = ioFactory::getInstance();
    OFactory = new OperationsFactory();


    //Type Selection
    ui->Type->addItem("Integer");
    ui->Type->addItem("String");
    ui->Type->addItem("StringList");

    //Arithmetic
    ui->Add_or_Subtract->addItem("Add");
    ui->Add_or_Subtract->addItem("Subtract");

    //connect(ui->spinBox, SIGNAL(clicked()), this, SLOT(on_Add_clicked()));
    //connect(ui->spinBox, SIGNAL(clicked()), this, SLOT(on_Subtract_clicked()));
    connect(ui->spinBox, SIGNAL(clicked()), this, SLOT(on_Calculate_clicked()));
    //connect(ui->spinBox_2, SIGNAL(clicked()), this, SLOT(on_Calculate_clicked()));
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_Add_clicked()
{


        if(ui->radioInteger->isChecked())
        {


            QVariant x(ui->spinBox->value());
            qDebug() << x;
            QVariant y(ui->spinBox_2->value());
            qDebug() << y;

           Operations *i = new IntOperations();

           QVariant v = i->addition(x,y);

           int v1 = v.toInt();

           //QString v  = i->toString();

           //ui->textEdit->setPlainText(v1);
           ui->spinBox_3->setValue(v1);

           ui->comboBox_3->hide();
           ui->lineEdit_3->hide();
           ui->spinBox_3->show();
        }
        else if(ui->radioString->isChecked())
        {



            QVariant x(ui->lineEdit->text());
            qDebug() << x;
            QVariant y(ui->lineEdit_2->text());
            qDebug() << y;

            Operations *s = new StringOperations();

            QVariant v2 = s->addition(x, y);

            QString v3 = v2.toString();

            ui->lineEdit_3->setText(v3);

            ui->comboBox_3->hide();
            ui->lineEdit_3->show();
            ui->spinBox_3->hide();

        }
        else if(ui->radioStringList->isChecked())
        {
            ui->comboBox_3->show();
            ui->lineEdit_3->hide();
            ui->spinBox_3->hide();

        }


}

void MainWindow::on_Subtract_clicked()
{



            if(ui->radioInteger->isChecked())
            {
                //Input data
                QVariant x(ui->spinBox->value());
                qDebug() << x;
                QVariant y(ui->spinBox_2->value());
                qDebug() << y;

                //Instantiate pointer object to IntOperations
               Operations *i = new IntOperations();

               //Call the subtract
               QVariant v = i->subtraction(x,y);

               int v1 = v.toInt();

               ui->spinBox_3->setValue(v1);

               //ui->textEdit->setPlainText(v1);
               //ui->textEdit->setPlainText(QString::number(v1));
               ui->comboBox_3->hide();
               ui->lineEdit_3->hide();
               ui->spinBox_3->show();



            }
            else if(ui->radioString->isChecked())
            {
                QVariant x(ui->lineEdit->text());
                qDebug() << x;
                QVariant y(ui->lineEdit_2->text());
                qDebug() << y;

                Operations *s = new StringOperations();

                QVariant v2 = s->subtraction(x, y);

                ui->lineEdit_3->setText(v2.toString());



                //ui->textEdit->setPlainText(QVariant(v2).toString());

                ui->comboBox_3->hide();
                ui->lineEdit_3->show();
                ui->spinBox_3->hide();

            }
            else if(ui->radioStringList->isChecked())
            {
//                QString type = ui->comboBox->currentText();

//                f1 = factory->createIOField(type);
//                f2 = factory->createIOField(type);

//                QWidget*


                ui->comboBox_3->show();
                ui->lineEdit_3->hide();
                ui->spinBox_3->hide();
            }



}





void MainWindow::on_Calculate_clicked()
{
    QString value = ui->Type->currentText();



    ////////////////////////////////////////////////////

    QString addOrSubtract = ui->Add_or_Subtract->currentText();

    if(addOrSubtract  == "Add")
    {

        if(value == "Integer")
        {




    //            return new IntIOField();

            //Input data
            QVariant x(ui->spinBox->value());
            qDebug() << x;
            QVariant y(ui->spinBox_2->value());
            qDebug() << y;

            //Instantiate pointer object to IntOperations
           Operations *i = new IntOperations();

           //Call the subtract
           QVariant v = i->addition(x,y);

           int v1 = v.toInt();

           //QString v  = i->toString();

           ui->spinBox_3->setValue(v1);
           //ui->textEdit->setPlainText(QString::number(v1));

           ui->comboBox_3->hide();
           ui->lineEdit_3->hide();
           ui->spinBox_3->show();


        }
        else if(value  == "String")
        {



    //            return new StringIOField();

            QVariant x(ui->lineEdit->text());
            qDebug() << x;
            QVariant y(ui->lineEdit_2->text());
            qDebug() << y;

            Operations *s = new StringOperations();

            QVariant v2 = s->addition(x, y);

            ui->lineEdit_3->setText(v2.toString());



            //ui->textEdit->setPlainText(QVariant(v2).toString());
            ui->comboBox_3->hide();
            ui->lineEdit_3->show();
            ui->spinBox_3->hide();



        }
        else if(value == "StringList")
        {

            ui->comboBox_3->show();
            ui->lineEdit_3->hide();
            ui->spinBox_3->hide();
            //Need to create a forloop to list array of characters
        }
    }
    else if(addOrSubtract  == "Subtract")
    {
        if(value == "Integer")
        {
    //            return new IntIOField();

            //Input data
            QVariant x(ui->spinBox->value());
            qDebug() << x;
            QVariant y(ui->spinBox_2->value());
            qDebug() << y;

            //Instantiate pointer object to IntOperations
           Operations *i = new IntOperations();

           //Call the subtract
           QVariant v = i->subtraction(x,y);

           int v1 = v.toInt();



           ui->spinBox_3->setValue(v1);

           ui->comboBox_3->hide();
           ui->lineEdit_3->hide();
           ui->spinBox_3->show();


        }
        else if(value  == "String")
        {
    //            return new StringIOField();

            QVariant x(ui->lineEdit->text());
            qDebug() << x;
            QVariant y(ui->lineEdit_2->text());
            qDebug() << y;

            Operations *s = new StringOperations();

            QVariant v2 = s->subtraction(x, y);

            ui->spinBox_3->setValue(v2.toInt());



            //ui->textEdit->setPlainText(QVariant(v2).toString());

            ui->comboBox_3->hide();
            ui->lineEdit_3->show();
            ui->spinBox_3->hide();



        }
        else if(value == "StringList")
        {
            ui->comboBox_3->show();
            ui->lineEdit_3->hide();
            ui->spinBox_3->hide();
    //            return new StringListIOField();
        }
    }

}


void MainWindow::on_radioInteger_clicked()
{
    ui->spinBox->show();
    ui->spinBox_2->show();
    ui->spinBox_3->show();

    ui->label->show();
    ui->label_2->show();

    ui->lineEdit->hide();
    ui->lineEdit_2->hide();
    ui->lineEdit_3->hide();

    ui->label_3->hide();
    ui->label_4->hide();

    ui->comboBox->hide();
    ui->comboBox_2->hide();
    ui->comboBox_3->hide();


}

void MainWindow::on_radioString_clicked()
{


    ui->lineEdit->show();
    ui->lineEdit_2->show();
    ui->lineEdit_3->show();

    ui->label_3->show();
    ui->label_4->show();

    ui->spinBox->hide();
    ui->spinBox_2->hide();
    ui->spinBox_3->hide();

    ui->label->hide();
    ui->label_2->hide();

    ui->comboBox->hide();
    ui->comboBox_2->hide();
    ui->comboBox_3->hide();

    ui->label_5->hide();
    ui->label_6->hide();




}

void MainWindow::on_radioStringList_clicked()
{
    ui->comboBox->show();
    ui->comboBox_2->show();
    ui->comboBox_3->show();

    ui->label_5->show();
    ui->label_6->show();

    ui->spinBox->hide();
    ui->spinBox_2->hide();
    ui->spinBox_3->hide();

    ui->label->hide();
    ui->label_2->hide();

    ui->lineEdit->hide();
    ui->lineEdit_2->hide();
    ui->lineEdit_3->hide();

    ui->label_3->hide();
    ui->label_4->hide();




}

void MainWindow::on_Type_activated(int index)
{

    QString value = ui->Type->currentText();

    if(value == "Integer")
    {
        ui->radioInteger->setChecked(true);

        ui->spinBox->show();
        ui->spinBox_2->show();

        ui->label->show();
        ui->label_2->show();

        ui->lineEdit->hide();
        ui->lineEdit_2->hide();

        ui->label_3->hide();
        ui->label_4->hide();

        ui->comboBox->hide();
        ui->comboBox_2->hide();

        ui->label_5->hide();
        ui->label_6->hide();

        ui->comboBox_3->hide();
        ui->lineEdit_3->hide();
        ui->spinBox_3->show();
    }
    else if(value  == "String")
    {

        ui->radioString->setChecked(true);

        ui->lineEdit->show();
        ui->lineEdit_2->show();

        ui->label_3->show();
        ui->label_4->show();

        ui->spinBox->hide();
        ui->spinBox_2->hide();

        ui->label->hide();
        ui->label_2->hide();

        ui->comboBox->hide();
        ui->comboBox_2->hide();

        ui->label_5->hide();
        ui->label_6->hide();

        ui->comboBox_3->hide();
        ui->lineEdit_3->show();
        ui->spinBox_3->hide();
    }
    else if(value == "StringList")
    {
        ui->radioStringList->setChecked(true);

        ui->comboBox->show();
        ui->comboBox_2->show();

        ui->label_5->show();
        ui->label_6->show();

        ui->spinBox->hide();
        ui->spinBox_2->hide();

        ui->label->hide();
        ui->label_2->hide();

        ui->lineEdit->hide();
        ui->lineEdit_2->hide();

        ui->label_3->hide();
        ui->label_4->hide();

        ui->comboBox_3->show();
        ui->lineEdit_3->hide();
        ui->spinBox_3->hide();
    }
}



void MainWindow::on_CalculateTest_clicked()
{
    QVariant v1 = f1->getValue();
    QVariant v2 = f2->getValue();

    Operations *O;
    O = OFactory->create(ui->Type->currentText());
    QVariant value;

    if(ui->Add_or_Subtract->currentText() == "Add")
    {
        value = O->addition(v1, v2);
    }
    else if(ui->Add_or_Subtract->currentText() == "Subtract")
    {
        value = O->subtraction(v1, v2);
    }

    IOField* OI = factory->createIOField(ui->Type->currentText());


//        layout->addWidget(inputField1, 1, 2);
//        ui->textEdit->setPlainText(QString::number(v1));




}
