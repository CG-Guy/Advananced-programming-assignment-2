#ifndef IOFIELD_H
#define IOFIELD_H
#include <QVariant>


class IOField
{
public:
    IOField();
    ~IOField();
    virtual QVariant getValue() = 0;
    virtual void setValue(QVariant value) = 0;
    virtual QWidget *getWidget() = 0;


};

#endif // IOFIELD_H
