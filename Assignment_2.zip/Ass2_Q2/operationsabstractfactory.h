#ifndef OPERATIONSABSTRACTFACTORY_H
#define OPERATIONSABSTRACTFACTORY_H
#include "operations.h"
#include "intoperations.h"
#include "stringlistoperations.h"

class OperationsAbstractFactory
{
public:
    OperationsAbstractFactory();

    virtual Operations* create(QString operation) = 0;




};

#endif // OPERATIONSABSTRACTFACTORY_H
