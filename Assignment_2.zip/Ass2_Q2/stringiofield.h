#ifndef STRINGIOFIELD_H
#define STRINGIOFIELD_H
#include "iofield.h"
#include <QLineEdit>


class StringIOField:public IOField
{
public:
    StringIOField();
    ~StringIOField();

    QVariant getValue();
    void setValue(QVariant value);
    QWidget *getWidget();

private:
    QLineEdit* stringField;
};

#endif // STRINGIOFIELD_H
