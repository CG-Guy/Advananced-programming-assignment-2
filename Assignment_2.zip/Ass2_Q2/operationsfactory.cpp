#include "operationsfactory.h"

OperationsFactory::OperationsFactory()
{
}

Operations *OperationsFactory::create(QString type)
{

    QVariant t;

        if(type == "Integer")
        {
                return new IntOperations();
        }
        else if(type  == "String")
        {
                return new StringOperations();
        }
        else if(type  == "String List")
        {
                return new StringListOperations();
        }

        return NULL;
}
