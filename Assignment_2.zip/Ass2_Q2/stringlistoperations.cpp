#include "stringlistoperations.h"




StringListOperations::StringListOperations()
{

}

QVariant StringListOperations::addition(QVariant x, QVariant y)
{
    QStringList X = x.toStringList();
    QStringList Y = y.toStringList();

    QStringList value;

    value = X + Y;

    return value;
}

QVariant StringListOperations::subtraction(QVariant x, QVariant y)
{
    QStringList X = x.toStringList();
    QStringList Y = y.toStringList();


    //void remove(QStringList& list, const QStringList& toDelete){
      QStringListIterator i(Y);
      while(i.hasNext())
      {
            X.removeAll(i.next());
      }


    return X;
}
