#include "operations.h"
#include "intoperations.h"
#include "stringoperations.h"
#include "stringlistoperations.h"


Operations::Operations()
{
//    x = X;
//    y = Y;
}





QVariant Operations::getValue1() const
{
    return x;
}

QVariant Operations::getValue2() const
{
    return y;
}

QVariant Operations::setValue1(QVariant X)
{
    X = x;
}

QVariant Operations::setValue2(QVariant Y)
{
    Y = y;
}




QVariant Operations::addition(QVariant x, QVariant y)
{

}

QVariant Operations::subtraction(QVariant x, QVariant y)
{

}
