#ifndef STRINGOPERATIONS_H
#define STRINGOPERATIONS_H
#include "operations.h"

#include <QString>
#include <QVariant>
#include <QObject>

class StringOperations : public Operations
{

public:

    StringOperations();
    QVariant addition(QVariant x, QVariant y);
    QVariant subtraction(QVariant x, QVariant y);






private:
    QString X,Y;
};



#endif // STRINGOPERATIONS_H
