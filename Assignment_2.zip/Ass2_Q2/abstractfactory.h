#ifndef ABSTRACTFACTORY_H
#define ABSTRACTFACTORY_H


#include "iofield.h"
#include "intiofield.h"
#include "stringiofield.h"
#include "stringlistiofield.h"

class AbstractFactory
{
public:
    AbstractFactory();
     virtual IOField* createIOField(QString type) = 0;
};

#endif // ABSTRACTFACTORY_H
