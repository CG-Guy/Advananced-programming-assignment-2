#include "iofield.h"







IOField::IOField()
{

}

IOField::~IOField()
{

}
