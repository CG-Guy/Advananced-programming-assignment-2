#include "stringlistiofield.h"
#include <QDebug>



StringListIOField::StringListIOField()
{
    stringListField = new QComboBox;
}

StringListIOField::~StringListIOField()
{
    delete stringListField;
}

QVariant StringListIOField::getValue()
{

    QStringList items;

    for(int i = 0; i <stringListField->count();i++)
    {
        items.append(stringListField->itemText(i));
    }

    return items;

}

void StringListIOField::setValue(QVariant value)
{
    stringListField->addItems(value.toStringList());
}

QWidget *StringListIOField::getWidget()
{
    qDebug() <<"stringListField";
    return stringListField;

}
