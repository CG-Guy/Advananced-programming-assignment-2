#include "stringoperations.h"
#include <QDebug>

StringOperations::StringOperations()
{
}


QVariant StringOperations::addition(QVariant x, QVariant y)\
{
    QString v1 = x.toString();
    qDebug() << v1;
    QString v2 = y.toString();
    qDebug() << v2;

    QString value = v1 + v2;
    qDebug() <<"v1 + v2 = " << value;

    return value;

}

QVariant StringOperations::subtraction(QVariant x, QVariant y)
{
      QString v1 = x.toString();
      qDebug() << v1;
      QString v2 = y.toString();
      qDebug() << v2;

//    QString value = v1 - v2;
//    qDebug() <<"v1 - v2 = " << value;


    QString value = v1;
    value.remove(v2);



    qDebug() <<"Subtract string: " << value;

    return value;
}



