#ifndef OPERATIONS_H
#define OPERATIONS_H
#include "operations.h"

#include <QString>
#include <QVariant>
#include <QMetaEnum>

class Operations:public QObject
{

public:

    //Q_ENUM(Model);


    Operations();


    QVariant getValue1() const;
    QVariant getValue2() const;

    QVariant setValue1(QVariant);
    QVariant setValue2(QVariant);


    virtual QVariant addition(QVariant x, QVariant y);
    virtual QVariant subtraction(QVariant x, QVariant y);


protected:
    QVariant x;
    QVariant y;
};

#endif // OPERATIONS_H
