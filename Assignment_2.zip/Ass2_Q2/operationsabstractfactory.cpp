#include "operationsabstractfactory.h"

OperationsAbstractFactory::OperationsAbstractFactory()
{
}
