#include "intoperations.h"
#include "stringoperations.h"
#include "stringlistoperations.h"
#include "mainwindow.h"
#include <QDebug>



IntOperations::IntOperations()
{

}



QVariant IntOperations::addition(QVariant x, QVariant y)
{


    int v1 = x.toInt();
    qDebug() <<v1;
    int v2 = y.toInt();
    qDebug() <<v2;


    int value = v1 + v2;
    qDebug() << value;


    return value;

}

QVariant IntOperations::subtraction(QVariant x, QVariant y)
{

    int v1 = x.toInt();
    qDebug() <<v1;
    int v2 = y.toInt();
    qDebug() <<v2;


    int value = v1 - v2;
    qDebug() << value;


    return value;
}




