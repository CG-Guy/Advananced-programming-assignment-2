#ifndef INTIOFIELD_H
#define INTIOFIELD_H
#include "iofield.h"
#include <QSpinBox>

class IntIOField:public IOField
{
public:
    IntIOField();
    ~IntIOField();

    QVariant getValue();
    void setValue(QVariant value);
    QWidget *getWidget();

private:
    QSpinBox* intField;

};

#endif // INTIOFIELD_H
