#ifndef INTOPERATIONS_H
#define INTOPERATIONS_H
#include "operations.h"

#include <QString>
#include <QVariant>
#include <QObject>

class IntOperations : public Operations
{

public:

    IntOperations();


    QVariant addition(QVariant x, QVariant y);
    QVariant subtraction(QVariant x, QVariant y);
    QString toString();

private:
    int X,Y;


};

#endif // INTOPERATIONS_H
