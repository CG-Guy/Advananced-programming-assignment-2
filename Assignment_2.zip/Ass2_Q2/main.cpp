#include "mainwindow.h"
#include <QApplication>
#include <QTextStream>
#include <QFile>
#include <QDataStream>
#include <QMetaEnum>
#include <QDebug>

#include "operations.h"


QTextStream cout(stdout);

QTextStream cin(stdin);
#include <QVariant>
#include <QString>


int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    
    

    qDebug() <<"test";

    MainWindow w;
    w.show();

    return a.exec();
}
