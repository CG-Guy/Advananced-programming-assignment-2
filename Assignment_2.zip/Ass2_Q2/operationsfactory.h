#ifndef OPERATIONSFACTORY_H
#define OPERATIONSFACTORY_H
#include "operationsabstractfactory.h"
#include "intoperations.h"
#include "stringoperations.h"
#include "stringlistoperations.h"

class OperationsFactory:public OperationsAbstractFactory
{
public:
    OperationsFactory();
    Operations* create(QString operation);
};

#endif // OPERATIONSFACTORY_H
