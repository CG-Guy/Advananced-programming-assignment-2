#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "abstractfactory.h"
#include "operationsabstractfactory.h"
#include "iofactory.h"
#include "operationsfactory.h"
#include <QGridLayout>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private slots:

    void on_Add_clicked();

    void on_Subtract_clicked();

    void on_Calculate_clicked();


    void on_radioInteger_clicked();

    void on_radioString_clicked();

    void on_radioStringList_clicked();

    void on_Type_activated(int index);


    void on_CalculateTest_clicked();

private:
    Ui::MainWindow *ui;
    IOField* f1;
    IOField* f2;
    AbstractFactory* factory;
    OperationsAbstractFactory* OFactory;
};

#endif // MAINWINDOW_H
