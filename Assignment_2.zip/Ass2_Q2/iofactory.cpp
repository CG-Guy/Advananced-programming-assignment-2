#include "iofactory.h"

//This is part of the singleton Pattern implementation (This is important)
ioFactory *ioFactory::OneInstance = NULL;



ioFactory* ioFactory::getInstance()
{
    if(OneInstance == NULL)
    {
        OneInstance = new ioFactory();
    }
    return OneInstance;
}

//
IOField *ioFactory::createIOField(QString VariableType)
{
    if(VariableType == "Integer")
    {
            return new IntIOField();
    }
    else if(VariableType == "String")
    {
            return new StringIOField();
    }
    else if(VariableType == "StringList")
    {
            return new StringListIOField();
    }

    return NULL;
}

ioFactory::ioFactory()
{
}
