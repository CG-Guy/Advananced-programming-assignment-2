#ifndef INVESTMENTCALCULATOR_H
#define INVESTMENTCALCULATOR_H

#include <QThread>
#include <QObject>

//Worker class
class InvestmentCalculator : public QObject //QThread can also work
{
    Q_OBJECT
public:
    //explicit InvestmentCalculator(QObject *parent = 0);
    InvestmentCalculator(float I, float IR, int Y);


    bool stop;

//    void calculate();

signals:

    //Use atleast two signals (on for emitting signal when finished and the other when values change)
    void ValueChanged(float);
    void finished();

public slots:
     void run();

private:
    float Investment;
    float Interest_Rate;
    int num_Years;




};

#endif // INVESTMENTCALCULATOR_H
