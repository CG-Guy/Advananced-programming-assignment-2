#include "dialog.h"
#include "ui_dialog.h"
#include <QtMath>


Dialog::Dialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog)
{
    ui->setupUi(this);

}

Dialog::~Dialog()
{
    delete ui;
}

void Dialog::OnValueChanged(float A)
{

//    //Investment growth formula
//    float Rate = rate(ui->doubleSpinBox->value()); //Rate
//    float Inv = investment(ui->doubleSpinBox_2->value()); //Number of years
//    int Years = years(ui->doubleSpinBox_3->value()); //period

//    InvestmentCalculator i;
//    A = i.calculate(Inv, Rate, Years);


//    //A = (qPow((P*(1 + (rate))-P), numYears));


//    ui->textEdit->setText(QString::number(A));

//    ui->label_4->setText(QString::number(A));
}

void Dialog::on_Start_clicked()
{
    mThread = new QThread();

    //Investment growth formula
    float rate(ui->doubleSpinBox->value()); //Rate
    float investment(ui->doubleSpinBox_2->value()); //Number of years
    int years(ui->doubleSpinBox_3->value()); //period


    InvestmentCalculator *run = new InvestmentCalculator(investment, rate, years);

    run->moveToThread(mThread);


    connect(mThread, SIGNAL(started()), run, SLOT(run()));

    connect(run, SIGNAL(ValueChanged(float)), this, SLOT(display(float)));

    connect(run, SIGNAL(finished()), mThread, SLOT(quit()));
    connect(run, SIGNAL(finished()), run , SLOT(deleteLater()));
    connect(mThread, SIGNAL(finished()), mThread , SLOT(deleteLater()));

    //Started
    mThread->start();

}

void Dialog::on_Stop_clicked()
{

    //Stopped
    mThread->quit();
}


void Dialog::display(float investment)
{
    //Display amount
    ui->textEdit->setText(ui->textEdit->toPlainText().append(QString("\n%1").arg(investment)));

    ui->lineEdit->setText(QString("\n%1").arg(investment));

}
