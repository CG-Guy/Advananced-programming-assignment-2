#include "investmentcalculator.h"
#include <QtCore>

//InvestmentCalculator::InvestmentCalculator(QObject *parent) :
//    QThread(parent)
//{

//}

InvestmentCalculator::InvestmentCalculator(float I, float IR, int Y)
{
    Investment = I;
    Interest_Rate =  IR;
    num_Years =  Y;
}

void InvestmentCalculator::run()
{
    for(int i = 0; i < num_Years; i++)
    {
//        QMutex mutex;
//        mutex.lock();

//        if(this->stop) break;
//        mutex.unlock();

//        emit ValueChanged(i);
//          this->msleep(100);


        Investment += pow((1+(Interest_Rate/100)), num_Years);

        emit ValueChanged(Investment);


        QThread::msleep(100);
    }

    emit finished();
}

//void InvestmentCalculator::calculate()
//{
//    return Investment += (Investment*(Interest_Rate/100));
//}


