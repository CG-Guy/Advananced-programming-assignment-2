#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include "contactlist.h"
#include <QMainWindow>
#include <QCloseEvent>


namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();


private slots:
    void on_Add_clicked();
    void on_Delete_clicked();
    void closeEvent();


private:
    Ui::MainWindow *ui;
    //QList<Contact*> contactList;
    ContactList *x;
};



#endif // MAINWINDOW_H
