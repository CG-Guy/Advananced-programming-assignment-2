#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "contact.h"
#include "contactlist.h"
#include <QFile>
#include <QXmlInputSource>
#include <QCloseEvent>
#include <QXmlStreamWriter>
#include "saxhandler.h"
#include "filewriter.h"
#include "qobjectwriter.h"
#include <QMessageBox>
QTextStream cout(stdout);


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);



//    QString directory = "Contact.xml";//XML file

    SaxHandler reader; //Read the SAX

//    bool condition = reader.parse(directory);//Detect and interpret the XML. Builds the XML object. bool = successfull or not

//    if(!condition)
//    {
//        QMessageBox::warning(0, "Cannot read xml", "Cannot read xml");
//        x = new ContactList;
//    }else{
//        QMessageBox::information(0, "Read successfully", "Read successfully");

        x = reader.getList();//Set the SAX list to a list

        ui->textEdit->setText(x->toString()); //Write the list to the textEdit
//    }


////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////Read From File////////////////////////////////////////////////////



//        //Ask for the file location
//        if (!QFile::exists("samplefile.xml")) {
//            //qDebug() << "XMLIMPORT: unable to open " << "contacts.xml";
//            return;
//        }

//       //Read the file and load companies uisingf the file reader
//       QFile xmlFile("samplefile.xml");
//       QXmlInputSource source( &xmlFile );
//       QXmlSimpleReader reader;
//       reader.setContentHandler( 0 );
//       reader.parse( source );



}

MainWindow::~MainWindow()
{

    //Need to learn this *************NB*************
    QString directory = "Contact.xml";

    QObjectWriter ObjectWriter;

    QString xml = ObjectWriter.toString(x);//Write list to string

    FileWriter FW;

    FW.Writer(directory, xml);

    delete ui;
}



void MainWindow::on_Add_clicked()
{


    //    Contact* ci = new Contact(5,"Jay", "Manale", "School of Computing, UNISA", "0003", "Pretoria","012 345 678");


    //Assign components to variables
    int category = ui->spinBox->value();
    QString firstName = ui->lineEdit_14->text();
    QString lastName = ui->lineEdit_15->text();
    QString streetAddress = ui->lineEdit_16->text();
    QString zipCode = ui->lineEdit_17->text();
    QString city = ui->lineEdit_18->text();
    QString phoneNumber = ui->lineEdit_19->text();



    Contact* ci = new Contact(category,firstName, lastName, streetAddress, zipCode, city,phoneNumber);

    //Adding a new contact
    x->add(ci);

//    QString v = ci->toString();

    ui->textEdit->setText(x->toString());





}

void MainWindow::on_Delete_clicked()
{


    //    Contact* ci = new Contact(5,"Jay", "Manale", "School of Computing, UNISA", "0003", "Pretoria","012 345 678");


        //Assign components to variable
        int category = ui->spinBox->value();
        QString firstName = ui->lineEdit_14->text();
        QString lastName = ui->lineEdit_15->text();
        QString streetAddress = ui->lineEdit_16->text();
        QString zipCode = ui->lineEdit_17->text();
        QString city = ui->lineEdit_18->text();
        QString phoneNumber = ui->lineEdit_19->text();



        Contact* ci = new Contact(category,firstName, lastName, streetAddress, zipCode, city,phoneNumber);


        QString v = ci->toString();

        //Removing selected items
        x->remove(ci);
         ui->textEdit->setText(v);

}





void MainWindow::closeEvent()
{

    //////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////////////////////////Write to File////////////////////////////////////////////////////


//    //Contact *v;

//    int category = ui->spinBox->value();
//    QString firstName = ui->lineEdit_14->text();
//    QString lastName = ui->lineEdit_15->text();
//    QString streetAddress = ui->lineEdit_16->text();
//    QString zipCode = ui->lineEdit_17->text();
//    QString city = ui->lineEdit_18->text();
//    QString phoneNumber = ui->lineEdit_19->text();



//        QFile xmlFile("contacts.xml");
//        xmlFile.open(QIODevice::WriteOnly);

//        QXmlStreamWriter xmlWriter(&xmlFile);
//        xmlWriter.setAutoFormatting(true);
//        xmlWriter.writeStartDocument();

//        xmlWriter.writeStartElement("Contacts");

////        xmlWriter.writeStartElement("Category");
////        xmlWriter.writeTextElement("List of Numbers", "statevalue" );
////        xmlWriter.writeTextElement("Room", "roomvalue");
////        xmlWriter.writeTextElement("Potencial", "potencialvalue");

//        xmlWriter.writeTextElement("Category", QString::number(category)  );
//        xmlWriter.writeTextElement("First Name", firstName );
//        xmlWriter.writeTextElement("Last Name", lastName);
//        xmlWriter.writeTextElement("Street Address", streetAddress);
//        xmlWriter.writeTextElement("Zip Code", zipCode);
//        xmlWriter.writeTextElement("City", city );
//        xmlWriter.writeTextElement("Phone Number", phoneNumber );

//        xmlWriter.writeEndElement();
//        xmlWriter.writeEndDocument();

//        xmlFile.close();
}


