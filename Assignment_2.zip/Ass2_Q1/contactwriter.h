#ifndef CONTACTWRITER_H
#define CONTACTWRITER_H

class ContactWriter
{
public:
    ContactWriter();
};

#endif // CONTACTWRITER_H
