#include "saxhandler.h"

#include <QString>
#include <QTextStream>

////start
////QTextStream cout(stdout);

//bool SaxHandler::startDocument() {
//    indent = "";
//    return true;
//}

//bool SaxHandler::characters(const QString& text) {
//    QString t = text;
//    //cout << t.remove('\n');
//    return true;
//}

//bool SaxHandler::startElement( const QString&, /* We have omitted the names of the parameters that we don't use. This prevents the compiler from issuing "unused parameter" warnings. */
//                             const QString&, const QString& qName,
//                             const QXmlAttributes& atts) {
//    QString str = QString("\n%1\\%2").arg(indent).arg(qName);
//    //cout << str;
//    if (atts.length()>0) {
//        QString fieldName = atts.qName(0);
//        QString fieldValue = atts.value(0);
//        //cout << QString("(%2=%3)").arg(fieldName).arg(fieldValue);
//    }
//   // cout << "{";
//    indent += "    ";
//    return true;
//}

//bool SaxHandler::endElement( const QString&,
//    const QString& , const QString& ) {
//    indent.remove( 0, 4 );
//   // cout << "}";
//    return true;
//}
////end






SaxHandler::SaxHandler()
{
    List = new ContactList();
}

bool SaxHandler::startElement(/*const QString &namespaceURI, const QString &localName,*/ const QString &qName/* xml Tags*/, const QXmlAttributes &atts/*variable*/)
{
    //If the Contact and object is found under ContactList in xml, continue
    if(qName=="object" && atts.value("class")=="Contact")
    {
        Is_Contact = true;
    }

    //If property (tag) is found in xml, continue
    if(qName == "property")
    {

        //If (attributes) are found in xml, continue
        if(atts.value("name") == "firstName")
        {
            firstName = atts.value("value");
        }
        if(atts.value("name") == "lastName")
        {
            lastName = atts.value("value");
        }
        if(atts.value("name") == "streetAddress")
        {
            streetAddress = atts.value("value");
        }
        if(atts.value("name") == "zipCode")
        {
            zipCode = atts.value("value");
        }
        if(atts.value("name") == "city")
        {
            city = atts.value("value");
        }
        if(atts.value("name") == "phoneNumber")
        {
            phoneNumber = atts.value("value");
        }
    }

    return true;
}

bool SaxHandler::endElement(/*const QString &namespaceURI, const QString &localName,*/ const QString &qName)
{
    if(qName == "object")
    {
        if(Is_Contact)
        {
            Contact *Contact_value = new Contact(category, firstName, lastName, streetAddress, zipCode, city, phoneNumber);
           List->add(Contact_value );
        }

        Is_Contact = false;//Determine that final tag of the xml is read(At end). Allows it to start from beginning if QOject is founs
    }

    return true;
}

bool SaxHandler::parse(QString directory)
{
    QFile file(directory);//File location

    QXmlInputSource xmlInputSource(&file);//Create XML file (connect to file)

    QXmlSimpleReader reader;//Read xml

    reader.setContentHandler(this);//This setContectHander understand how to read the XML

    bool condition = reader.parse(xmlInputSource);//Check condition if read


    return condition;
}

ContactList *SaxHandler::getList()
{
    return List;
}
