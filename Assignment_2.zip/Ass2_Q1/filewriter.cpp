#include "filewriter.h"

FileWriter::FileWriter()
{
}

bool FileWriter::Writer(QString path, QString xml)
{
    QFile file(path); //Determine file location

    if(file.open(QIODevice::WriteOnly)) //Check that file is open
    {
        QTextStream stream(&file); //Create file

        stream << xml; //Send to file

        file.close();

        return true;

    }
    return false;
}
