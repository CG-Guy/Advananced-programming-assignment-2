#include "contactwriter.h"

ContactWriter::ContactWriter()
{
}
