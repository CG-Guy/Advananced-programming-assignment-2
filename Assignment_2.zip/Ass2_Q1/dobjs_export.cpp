#include "dobjs_export.h"

dobjs_export::dobjs_export()
{
}
