#ifndef SAXHANDLER_H
#define SAXHANDLER_H

#include <QString>
#include <QtXml/QXmlDefaultHandler>
#include "contact.h"
#include "contactlist.h"


class SaxHandler: public QXmlDefaultHandler //QXmlDefaultHandler is a abstract class
{
public:
    SaxHandler();
    //SaxHandler::SaxHandler():QXmlDefaultHandler(),contact(0), contactList(QString::null){}

    //bool startDocument();

    //bool endDocument();



    bool startElement(/*const QString &namespaceURI, const QString &localName,*/
                      const QString &qName, const QXmlAttributes &atts);

    bool endElement(/*const QString &namespaceURI, const QString &localName,*/
                    const QString &qName);


     //bool characters(const QString & directory);

     bool parse(QString directory);

    ContactList *getList();


private:
    int category;
    QString firstName;
    QString lastName;
    QString streetAddress;
    QString zipCode;
    QString city;
    QString phoneNumber;

    bool Is_Contact;
    QString indent;

    ContactList *List;

};

#endif // SAXHANDLER_H
