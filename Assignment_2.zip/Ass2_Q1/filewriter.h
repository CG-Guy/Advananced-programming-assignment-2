#ifndef FILEWRITER_H
#define FILEWRITER_H
#include <QString>
#include <QFile>
#include <QTextStream>

class FileWriter
{
public:
    FileWriter();

    bool Writer(QString path, QString xml);
};

#endif // FILEWRITER_H
